package android.support.v4.widget;

import android.widget.*;
import android.view.*;

class PopupWindowCompatKitKat
{
    public static void showAsDropDown(final PopupWindow popupWindow, final View view, final int n, final int n2, final int n3) {
        popupWindow.showAsDropDown(view, n, n2, n3);
    }
}
