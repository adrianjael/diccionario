package android.support.v4.app;

import android.text.*;

class ShareCompatJB
{
    public static String escapeHtml(final CharSequence charSequence) {
        return Html.escapeHtml(charSequence);
    }
}
