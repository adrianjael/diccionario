package android.support.design.widget;

import android.view.*;
import android.support.v4.view.*;

interface CoordinatorLayoutInsetsHelper
{
    void setupForWindowInsets(final View p0, final OnApplyWindowInsetsListener p1);
}
