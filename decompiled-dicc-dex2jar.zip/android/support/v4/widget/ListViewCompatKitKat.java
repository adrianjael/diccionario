package android.support.v4.widget;

import android.widget.*;

class ListViewCompatKitKat
{
    static void scrollListBy(final ListView listView, final int n) {
        listView.scrollListBy(n);
    }
}
