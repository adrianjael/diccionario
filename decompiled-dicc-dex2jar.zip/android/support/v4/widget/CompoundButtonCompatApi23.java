package android.support.v4.widget;

import android.widget.*;
import android.graphics.drawable.*;

class CompoundButtonCompatApi23
{
    static Drawable getButtonDrawable(final CompoundButton compoundButton) {
        return compoundButton.getButtonDrawable();
    }
}
