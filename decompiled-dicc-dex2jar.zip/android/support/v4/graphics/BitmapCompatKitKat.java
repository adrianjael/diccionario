package android.support.v4.graphics;

import android.graphics.*;

class BitmapCompatKitKat
{
    static int getAllocationByteCount(final Bitmap bitmap) {
        return bitmap.getAllocationByteCount();
    }
}
