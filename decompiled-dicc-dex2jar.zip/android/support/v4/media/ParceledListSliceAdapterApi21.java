package android.support.v4.media;

import java.util.*;
import android.media.browse.*;
import java.lang.reflect.*;

class ParceledListSliceAdapterApi21
{
    private static Constructor sConstructor;
    
    static {
        try {
            ParceledListSliceAdapterApi21.sConstructor = Class.forName("android.content.pm.ParceledListSlice").getConstructor(List.class);
        }
        catch (NoSuchMethodException ex) {}
        catch (ClassNotFoundException ex2) {
            goto Label_0022;
        }
    }
    
    static Object newInstance(List<MediaBrowser$MediaItem> instance) {
        try {
            instance = (IllegalAccessException)ParceledListSliceAdapterApi21.sConstructor.newInstance(instance);
            return instance;
        }
        catch (InstantiationException ex) {}
        catch (IllegalAccessException instance) {
            goto Label_0018;
        }
        catch (InvocationTargetException instance) {
            goto Label_0018;
        }
    }
}
