package android.support.annotation;

import java.lang.annotation.*;

@Retention(RetentionPolicy.CLASS)
public @interface VisibleForTesting {
}
