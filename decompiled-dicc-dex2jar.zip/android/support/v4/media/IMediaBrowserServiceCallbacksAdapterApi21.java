package android.support.v4.media;

import android.media.session.*;
import java.lang.reflect.*;
import android.os.*;

class IMediaBrowserServiceCallbacksAdapterApi21
{
    private Method mAsBinderMethod;
    Object mCallbackObject;
    private Method mOnConnectFailedMethod;
    private Method mOnConnectMethod;
    private Method mOnLoadChildrenMethod;
    
    IMediaBrowserServiceCallbacksAdapterApi21(Object forName) {
        this.mCallbackObject = forName;
        try {
            forName = (ClassNotFoundException)Class.forName("android.service.media.IMediaBrowserServiceCallbacks");
            final Class<?> forName2 = Class.forName("android.content.pm.ParceledListSlice");
            this.mAsBinderMethod = ((Class)forName).getMethod("asBinder", (Class<?>[])new Class[0]);
            this.mOnConnectMethod = ((Class)forName).getMethod("onConnect", String.class, MediaSession$Token.class, Bundle.class);
            this.mOnConnectFailedMethod = ((Class)forName).getMethod("onConnectFailed", (Class<?>[])new Class[0]);
            this.mOnLoadChildrenMethod = ((Class)forName).getMethod("onLoadChildren", String.class, forName2);
        }
        catch (NoSuchMethodException ex) {}
        catch (ClassNotFoundException forName) {
            goto Label_0103;
        }
    }
    
    IBinder asBinder() {
        try {
            return (IBinder)this.mAsBinderMethod.invoke(this.mCallbackObject, new Object[0]);
        }
        catch (IllegalAccessException ex) {}
        catch (InvocationTargetException binder) {
            goto Label_0022;
        }
    }
    
    void onConnect(final String ex, final Object o, final Bundle bundle) throws RemoteException {
        try {
            this.mOnConnectMethod.invoke(this.mCallbackObject, ex, o, bundle);
        }
        catch (IllegalAccessException ex2) {}
        catch (InvocationTargetException ex) {
            goto Label_0030;
        }
    }
    
    void onConnectFailed() throws RemoteException {
        try {
            this.mOnConnectFailedMethod.invoke(this.mCallbackObject, new Object[0]);
        }
        catch (IllegalAccessException ex) {}
        catch (InvocationTargetException ex2) {
            goto Label_0018;
        }
    }
    
    void onLoadChildren(final String ex, final Object o) throws RemoteException {
        try {
            this.mOnLoadChildrenMethod.invoke(this.mCallbackObject, ex, o);
        }
        catch (IllegalAccessException ex2) {}
        catch (InvocationTargetException ex) {
            goto Label_0026;
        }
    }
    
    static class Stub
    {
        static Method sAsInterfaceMethod;
        
        static {
            try {
                Stub.sAsInterfaceMethod = Class.forName("android.service.media.IMediaBrowserServiceCallbacks$Stub").getMethod("asInterface", IBinder.class);
            }
            catch (NoSuchMethodException ex) {}
            catch (ClassNotFoundException ex2) {
                goto Label_0024;
            }
        }
        
        static Object asInterface(IBinder invoke) {
            try {
                invoke = (InvocationTargetException)Stub.sAsInterfaceMethod.invoke(null, invoke);
                return invoke;
            }
            catch (IllegalAccessException ex) {}
            catch (InvocationTargetException invoke) {
                goto Label_0019;
            }
        }
    }
}
