package android.support.v4.view;

import android.view.*;

public interface OnApplyWindowInsetsListener
{
    WindowInsetsCompat onApplyWindowInsets(final View p0, final WindowInsetsCompat p1);
}
