package android.support.v4.widget;

interface DrawerLayoutImpl
{
    void setChildInsets(final Object p0, final boolean p1);
}
