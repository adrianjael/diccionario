package android.support.v4.view;

public interface ScrollingView
{
    int computeHorizontalScrollExtent();
    
    int computeHorizontalScrollOffset();
    
    int computeHorizontalScrollRange();
    
    int computeVerticalScrollExtent();
    
    int computeVerticalScrollOffset();
    
    int computeVerticalScrollRange();
}
