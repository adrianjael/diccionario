package android.support.v4.view;

import android.view.*;
import android.content.*;
import android.util.*;

public interface LayoutInflaterFactory
{
    View onCreateView(final View p0, final String p1, final Context p2, final AttributeSet p3);
}
