package android.support.v4.graphics.drawable;

import android.graphics.drawable.*;

public interface DrawableWrapper
{
    Drawable getWrappedDrawable();
    
    void setWrappedDrawable(final Drawable p0);
}
