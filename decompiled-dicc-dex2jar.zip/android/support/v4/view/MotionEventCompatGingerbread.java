package android.support.v4.view;

import android.view.*;

class MotionEventCompatGingerbread
{
    public static int getSource(final MotionEvent motionEvent) {
        return motionEvent.getSource();
    }
}
