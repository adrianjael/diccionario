package android.support.design.widget;

import android.view.*;

class ViewUtilsLollipop
{
    static void setBoundsViewOutlineProvider(final View view) {
        view.setOutlineProvider(ViewOutlineProvider.BOUNDS);
    }
}
