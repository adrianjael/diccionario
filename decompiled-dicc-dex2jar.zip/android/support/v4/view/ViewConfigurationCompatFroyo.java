package android.support.v4.view;

import android.view.*;

class ViewConfigurationCompatFroyo
{
    public static int getScaledPagingTouchSlop(final ViewConfiguration viewConfiguration) {
        return viewConfiguration.getScaledPagingTouchSlop();
    }
}
