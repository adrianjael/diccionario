package android.support.v4.view;

import android.view.*;

public interface ViewPropertyAnimatorUpdateListener
{
    void onAnimationUpdate(final View p0);
}
