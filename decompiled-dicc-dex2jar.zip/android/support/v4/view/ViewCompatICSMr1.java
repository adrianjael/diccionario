package android.support.v4.view;

import android.view.*;

class ViewCompatICSMr1
{
    public static boolean hasOnClickListeners(final View view) {
        return view.hasOnClickListeners();
    }
}
